// sessionManager.js - Manages session selection and validation

class SessionManager {
    constructor(config) {
        this.config = config;
        this.selectedSessions = [];
        this.selectedBackups = [];
        this.selectedTimeslot = null;
        this.bookedDates = new Set();
        this.dateCountMap = new Map();
        this.takenTimeslots = new Set();
        this.takenDateTimeSlots = new Set();
    }

    /**
     * Updates the booked dates, availability counts, and taken timeslots
     * @param {Set} bookedDates - Set of booked date strings
     * @param {Map} dateCountMap - Map of date counts
     * @param {Set} takenTimeslots - Set of taken instruction timeslots
     * @param {Set} takenDateTimeSlots - Set of taken date-time combinations
     */
    updateAvailability(bookedDates, dateCountMap, takenTimeslots = new Set(), takenDateTimeSlots = new Set()) {
        this.bookedDates = bookedDates;
        this.dateCountMap = dateCountMap;
        this.takenTimeslots = takenTimeslots;
        this.takenDateTimeSlots = takenDateTimeSlots;
    }

    /**
     * Checks if a date is available for booking
     * @param {string} dateString - Date in YYYY-MM-DD format
     * @returns {boolean} True if available
     */
    isDateAvailable(dateString) {
        const currentCount = this.dateCountMap.get(dateString) || 0;
        const isNotFull = currentCount < this.config.MAX_CONCURRENT_SESSIONS;
        const isNotBooked = !this.bookedDates.has(dateString);
        
        return isNotFull && isNotBooked;
    }

    /**
     * Checks if a date is available for the first session (instruction session)
     * This includes checking for blocked dates since instruction sessions cannot happen on blocked dates
     * @param {string} dateString - Date in YYYY-MM-DD format
     * @returns {boolean} True if available for instruction session
     */
    isDateAvailableForInstruction(dateString) {
        const isGenerallyAvailable = this.isDateAvailable(dateString);
        const isNotBlocked = !DateManager.isDateBlocked(dateString);
        
        return isGenerallyAvailable && isNotBlocked;
    }

    /**
     * Checks if a timeslot is available for booking on a specific date
     * @param {string} timeslot - Timeslot string
     * @param {string} dateString - Date in YYYY-MM-DD format (optional, uses first selected session if not provided)
     * @returns {boolean} True if available
     */
    isTimeslotAvailable(timeslot, dateString = null) {
        // Use the first selected session date if no date is provided
        const targetDate = dateString || (this.selectedSessions.length > 0 ? this.selectedSessions[0] : null);
        
        if (targetDate) {
            // Check if this specific date-time combination is taken
            const dateTimeKey = `${targetDate}_${timeslot}`;
            return !this.takenDateTimeSlots.has(dateTimeKey);
        }
        
        // If no date is available, return true (timeslot is available)
        return true;
    }

    /**
     * Selects or deselects the first session
     * @param {string} dateString - Date in YYYY-MM-DD format
     * @returns {Object} Result with success status and reset flag
     */
    selectFirstSession(dateString) {
        const wasSelected = this.selectedSessions.length > 0 && this.selectedSessions[0] === dateString;
        const previousFirst = this.selectedSessions.length > 0 ? this.selectedSessions[0] : null;
        
        if (wasSelected) {
            this.selectedSessions = [];
            return { success: true, reset: true, deselected: true };
        } else {
            this.selectedSessions = [dateString];
            const needsReset = previousFirst !== dateString;
            if (needsReset) {
                this.selectedBackups = [];
                this.selectedTimeslot = null;
            }
            return { success: true, reset: needsReset, deselected: false };
        }
    }

    /**
     * Selects or deselects a follow-up session
     * @param {string} dateString - Date in YYYY-MM-DD format
     * @returns {Object} Result with success status and message
     */
    selectFollowUpSession(dateString) {
        const sessionIndex = this.selectedSessions.indexOf(dateString);
        
        if (sessionIndex > -1) {
            this.selectedSessions.splice(sessionIndex, 1);
            this.selectedBackups = []; // Clear backups when sessions change
            return { success: true, deselected: true };
        } else {
            if (this.selectedSessions.length >= this.config.TOTAL_SESSIONS) {
                return { 
                    success: false, 
                    error: `You can only select ${this.config.TOTAL_SESSIONS} total sessions.` 
                };
            }
            this.selectedSessions.push(dateString);
            return { success: true, deselected: false };
        }
    }

    /**
     * Selects or deselects a backup session
     * @param {string} dateString - Date in YYYY-MM-DD format
     * @returns {Object} Result with success status and message
     */
    selectBackupSession(dateString) {
        const backupIndex = this.selectedBackups.indexOf(dateString);
        
        if (backupIndex > -1) {
            this.selectedBackups.splice(backupIndex, 1);
            return { success: true, deselected: true };
        } else {
            if (this.selectedBackups.length >= this.config.NUM_BACKUP_SESSIONS) {
                return { 
                    success: false, 
                    error: `You can only select ${this.config.NUM_BACKUP_SESSIONS} backup sessions.` 
                };
            }
            this.selectedBackups.push(dateString);
            return { success: true, deselected: false };
        }
    }

    /**
     * Sets the selected timeslot
     * @param {string} timeslot - Time slot string
     */
    setTimeslot(timeslot) {
        this.selectedTimeslot = timeslot;
    }

    /**
     * Checks if all required selections are complete
     * @returns {boolean} True if ready for review
     */
    isReadyForReview() {
        return this.selectedSessions.length === this.config.TOTAL_SESSIONS &&
               this.selectedBackups.length === this.config.NUM_BACKUP_SESSIONS &&
               this.selectedTimeslot !== null;
    }

    /**
     * Gets the remaining sessions needed
     * @returns {number} Number of remaining sessions
     */
    getRemainingSessionsCount() {
        return Math.max(0, this.config.TOTAL_SESSIONS - this.selectedSessions.length);
    }

    /**
     * Gets the follow-up sessions count (excluding first session)
     * @returns {number} Number of follow-up sessions selected
     */
    getFollowUpCount() {
        return this.selectedSessions.length > 1 ? this.selectedSessions.length - 1 : 0;
    }

    /**
     * Checks if a date is already selected in sessions
     * @param {string} dateString - Date in YYYY-MM-DD format
     * @returns {boolean} True if already selected
     */
    isDateSelectedInSessions(dateString) {
        return this.selectedSessions.includes(dateString);
    }

    /**
     * Checks if a date is already selected in backups
     * @param {string} dateString - Date in YYYY-MM-DD format
     * @returns {boolean} True if already selected
     */
    isDateSelectedInBackups(dateString) {
        return this.selectedBackups.includes(dateString);
    }

    /**
     * Gets sorted session and backup data for submission
     * @returns {Object} Sorted session data
     */
    getSubmissionData() {
        return {
            session_dates: [...this.selectedSessions].sort(),
            backup_dates: [...this.selectedBackups].sort(),
            instruction_timeslot: this.selectedTimeslot
        };
    }

    /**
     * Resets all selections
     */
    reset() {
        this.selectedSessions = [];
        this.selectedBackups = [];
        this.selectedTimeslot = null;
    }
}