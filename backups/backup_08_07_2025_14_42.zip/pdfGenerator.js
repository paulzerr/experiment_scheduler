// pdfGenerator.js - PDF generation functionality for experiment scheduler

/**
 * Generates and downloads a PDF summary of the experiment schedule
 * @param {Object} scheduleData - The schedule data object
 * @param {string} participantId - The participant ID for the filename
 */
function generateAndDownloadPDF(scheduleData, participantId) {
    const pdfStatusP = document.getElementById('pdfStatus');
    
    if (pdfStatusP) {
        pdfStatusP.textContent = 'Generating PDF...';
        pdfStatusP.className = 'status-box pending';
        pdfStatusP.classList.remove('hidden');
    }

    try {
        const { jsPDF } = window.jspdf;
        if (!jsPDF) {
            throw new Error("jsPDF library not found.");
        }
        const doc = new jsPDF();

        doc.setFontSize(18);
        doc.text("Experiment Schedule Summary", 14, 22);
        doc.setFontSize(12);
        doc.text(`Participant ID: ${participantId}`, 14, 32);

        let yPos = 45;
        doc.setFontSize(11);
        
        doc.text(`Instruction Session Time Slot: ${scheduleData.instruction_timeslot}`, 14, yPos);
        yPos += 10;
        
        doc.text(`Experiment Sessions (${scheduleData.session_dates.length}):`, 14, yPos);
        yPos += 6;
        scheduleData.session_dates.forEach((date, index) => {
            if (yPos > 270) { doc.addPage(); yPos = 20; }
            const prefix = index === 0 ? `First (Instruction at ${scheduleData.instruction_timeslot})` : `Session ${index + 1}`;
            doc.text(`  - ${prefix}: ${formatDateForDisplay(date)}`, 20, yPos);
            yPos += 6;
        });

        yPos += 4;
        doc.text(`Backup Sessions (${scheduleData.backup_dates.length}):`, 14, yPos);
        yPos += 6;
        scheduleData.backup_dates.forEach((date, index) => {
            if (yPos > 270) { doc.addPage(); yPos = 20; }
            doc.text(`  - Backup ${index + 1}: ${formatDateForDisplay(date)}`, 20, yPos);
            yPos += 6;
        });

        yPos = Math.max(yPos, 250);
        if (yPos > 270) { doc.addPage(); yPos = 20;}
        doc.text("Please keep this PDF for your records.", 14, yPos);
        doc.text("Contact the experimenters if you have any questions or need to make changes.", 14, yPos + 6);

        doc.save(`Experiment_Schedule_${participantId}.pdf`);
        
        if (pdfStatusP) {
            pdfStatusP.textContent = 'PDF downloaded successfully!';
            pdfStatusP.className = 'status-box success';
        }
    } catch (error) {
        console.error("PDF Generation Error:", error);
        if (pdfStatusP) {
            pdfStatusP.textContent = `PDF generation failed: ${error.message}`;
            pdfStatusP.className = 'status-box error';
        }
    }
}

/**
 * Formats a date string (YYYY-MM-DD) for display
 * @param {string} dateStringYYYYMMDD - Date string in YYYY-MM-DD format
 * @returns {string} Formatted date string
 */
function formatDateForDisplay(dateStringYYYYMMDD) {
    if (!dateStringYYYYMMDD) return 'N/A';
    const date = new Date(dateStringYYYYMMDD + 'T00:00:00');
    return date.toLocaleDateString(undefined, {
        weekday: 'long', year: 'numeric', month: 'long', day: 'numeric'
    });
}