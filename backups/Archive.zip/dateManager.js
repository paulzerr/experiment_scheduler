// dateManager.js - Centralized date management utilities

class DateManager {
    /**
     * Converts a Date object or a string into a YYYY-MM-DD string.
     * @param {Date|string} date - The date to convert.
     * @returns {string|null} The date in YYYY-MM-DD format or null if input is invalid.
     */
    static toYYYYMMDD(date) {
        if (!date) return null;
        const d = new Date(date);
        if (isNaN(d.getTime())) return null;
        
        const year = d.getUTCFullYear();
        const month = String(d.getUTCMonth() + 1).padStart(2, '0');
        const day = String(d.getUTCDate()).padStart(2, '0');
        
        return `${year}-${month}-${day}`;
    }

    /**
     * Converts various date inputs into a UTC Date object at midnight.
     * This ensures consistency and avoids timezone-related issues.
     * @param {Date|string} dateInput - The date to convert.
     * @returns {Date|null} A new Date object set to midnight UTC, or null if input is invalid.
     */
    static toUTCDate(dateInput) {
        if (!dateInput) return null;

        let date;
        if (dateInput instanceof Date) {
            date = new Date(dateInput);
        } else if (typeof dateInput === 'string') {
            // Handles 'YYYY-MM-DD' or 'YYYY-MM-DDTHH:mm:ss...'
            const datePart = dateInput.split('T')[0];
            const parts = datePart.split('-').map(Number);
            if (parts.length === 3 && parts.every(p => !isNaN(p))) {
                // new Date(year, monthIndex, day)
                date = new Date(Date.UTC(parts[0], parts[1] - 1, parts[2]));
            }
        }

        if (date && !isNaN(date.getTime())) {
            date.setUTCHours(0, 0, 0, 0);
            return date;
        }

        return null;
    }

    /**
     * Formats a Date object for display.
     * @param {Date} date - The date to format.
     * @returns {string} Human-readable date string.
     */
    static formatForDisplay(date) {
        if (!date) return 'N/A';
        return date.toLocaleDateString(undefined, {
            weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', timeZone: 'UTC'
        });
    }

    /**
     * Gets the next work day (Monday-Friday)
     * @param {Date} date - Starting date
     * @returns {Date} Next work day
     */
    static getNextWorkDay(date) {
        const nextDay = new Date(date);
        nextDay.setDate(date.getDate() + 1);
        
        const dayOfWeek = nextDay.getDay();
        if (dayOfWeek === 0) { // Sunday
            nextDay.setDate(nextDay.getDate() + 1);
        } else if (dayOfWeek === 6) { // Saturday
            nextDay.setDate(nextDay.getDate() + 2);
        }
        
        return nextDay;
    }

    /**
     * Generates a range of dates starting from a base date
     * @param {Date} startDate - Starting date
     * @param {number} days - Number of days to generate
     * @returns {Date[]} Array of Date objects
     */
    static generateDateRange(startDate, days) {
        const dates = [];
        for (let i = 0; i < days; i++) {
            const date = new Date(startDate);
            date.setDate(startDate.getDate() + i);
            dates.push(date);
        }
        return dates;
    }

    /**
     * Generates follow-up dates starting from a base date.
     * @param {Date} baseDate - The base date.
     * @param {number} days - Number of days to generate.
     * @returns {Date[]} Array of Date objects.
     */
    static generateFollowUpDates(baseDate, days) {
        const startDate = this.toUTCDate(baseDate);
        if (!startDate) return [];

        const dates = [];
        for (let i = 1; i <= days; i++) {
            const newDate = new Date(startDate);
            newDate.setUTCDate(startDate.getUTCDate() + i);
            dates.push(newDate);
        }
        return dates;
    }

    /**
     * Generates backup dates starting from the day after the last session.
     * @param {Date[]} sessionDates - Array of session dates.
     * @param {number} days - Number of backup days to generate.
     * @returns {Date[]} Array of Date objects.
     */
    static generateBackupDates(sessionDates, days) {
        if (!sessionDates || sessionDates.length === 0) return [];
        
        const sortedSessions = [...sessionDates].sort((a, b) => a.getTime() - b.getTime());
        const lastSessionDate = sortedSessions[sortedSessions.length - 1];

        const dates = [];
        for (let i = 1; i <= days; i++) {
            const newDate = new Date(lastSessionDate);
            newDate.setUTCDate(lastSessionDate.getUTCDate() + i);
            dates.push(newDate);
        }
        return dates;
    }

    /**
     * Checks if a date is blocked.
     * @param {Date} date - The date to check.
     * @returns {boolean} True if the date is blocked.
     */
    static isDateBlocked(date) {
        const dateString = this.toYYYYMMDD(date);
        const blockedDates = SCHEDULER_CONFIG.BLOCKED_DATES || [];
        return blockedDates.includes(dateString);
    }

    /**
     * Filters out blocked dates from an array of dates
     * @param {Date[]} dates - Array of Date objects
     * @returns {Date[]} Array of Date objects excluding blocked dates
     */
    static filterBlockedDates(dates) {
        return dates.filter(date => !this.isDateBlocked(date));
    }

    /**
     * Finds the first date from which the specified number of available weekdays can be found
     * within a reasonable timeframe (allowing for weekends and some blocked days)
     * @param {Date} startDate - Starting date to search from
     * @param {number} requiredDays - Number of available weekdays required
     * @param {function} isAvailableCallback - Function to check if a date is available
     * @param {number} maxSearchDays - Maximum days to search (default: 365)
     * @returns {Date|null} First date from which enough days are available, or null if not found
     */
    static findFirstConsecutiveAvailableDays(startDate, requiredDays, isAvailableCallback, maxSearchDays = 365) {
        let searchDate = this.toUTCDate(startDate);
        if (!searchDate) return null;

        let daysSearched = 0;

        while (daysSearched < maxSearchDays) {
            let consecutiveCount = 0;
            let checkDate = new Date(searchDate);
            let firstAvailableDate = null;
            let daysChecked = 0;
            // Allow some buffer for weekends and unavailable days
            const maxDaysToScan = requiredDays * 3;

            while (daysChecked < maxDaysToScan && consecutiveCount < requiredDays) {
                const dayOfWeek = checkDate.getUTCDay();

                // Only count weekdays
                if (dayOfWeek !== 0 && dayOfWeek !== 6) {
                    if (isAvailableCallback(checkDate)) {
                        if (consecutiveCount === 0) {
                            firstAvailableDate = new Date(checkDate);
                        }
                        consecutiveCount++;
                    } else {
                        // Reset if a non-available weekday breaks the chain
                        consecutiveCount = 0;
                        firstAvailableDate = null;
                    }
                }

                if (consecutiveCount >= requiredDays) {
                    return firstAvailableDate;
                }

                checkDate.setUTCDate(checkDate.getUTCDate() + 1);
                daysChecked++;
            }
            
            // If we found enough days, return the start of that period
            if (consecutiveCount >= requiredDays) {
                return firstAvailableDate;
            }

            // Move to the next day and continue the search
            searchDate.setUTCDate(searchDate.getUTCDate() + 1);
            daysSearched++;
        }

        return null; // No suitable period found
    }
}