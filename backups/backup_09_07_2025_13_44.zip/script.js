// script.js - Participant Scheduler for Supabase (Refactored)

// --- Supabase Configuration ---
let supabaseClient;
if (window.supabase) {
    supabaseClient = window.supabase.createClient(SUPABASE_CONFIG.URL, SUPABASE_CONFIG.ANON_KEY);
} else {
    console.error("Supabase SDK not loaded. Make sure the Supabase JS SDK script is included before this script.");
}

// --- DOM Elements ---
const elements = {
    participantInfo: document.getElementById('participantInfo'),
    errorMessages: document.getElementById('errorMessages'),
    loadingStatus: document.getElementById('loadingStatus'),
    schedulerContent: document.getElementById('schedulerContent'),
    session1Calendar: document.getElementById('session1Calendar'),
    timeslotSection: document.getElementById('timeslotSection'),
    timeslotButtons: document.getElementById('timeslotButtons'),
    selectedDateDisplay: document.getElementById('selectedDateDisplay'),
    followUpSection: document.getElementById('followUpSection'),
    followUpCalendar: document.getElementById('followUpCalendar'),
    followUpCount: document.getElementById('followUpCount'),
    backupSection: document.getElementById('backupSection'),
    backupCalendar: document.getElementById('backupCalendar'),
    backupCount: document.getElementById('backupCount'),
    reviewButton: document.getElementById('reviewButton'),
    summarySection: document.getElementById('summarySection'),
    logOutput: document.getElementById('logOutput'),
    submitButton: document.getElementById('submitButton'),
    submissionStatus: document.getElementById('submissionStatus'),
    pdfStatus: document.getElementById('pdfStatus')
};

// --- State Variables ---
let participantInfo = null;
let sessionManager = new SessionManager(SCHEDULER_CONFIG);

// --- Initialization ---
document.addEventListener('DOMContentLoaded', initializeScheduler);

async function initializeScheduler() {
    showLoading('Loading availability...');
    
    try {
        participantInfo = await getParticipantInfo();
        elements.participantInfo.textContent = `Participant ID: ${participantInfo.participant_id}`;
        elements.participantInfo.classList.remove('hidden');

        await fetchAndUpdateAvailability();
        populateSession1Calendar();
        
        hideLoading();
        elements.schedulerContent.classList.remove('hidden');
    } catch (error) {
        console.error("Error initializing scheduler:", error);
        showError(error.message || "Failed to load availability. Please try refreshing the page.");
        hideLoading();
    }
}

async function getParticipantInfo() {
    const linkId = new URLSearchParams(window.location.search).get('uid');
    if (!linkId) throw new Error("Participant link ID not found in URL. Please use the link provided.");

    const { data, error } = await supabaseClient
        .from('schedules')
        .select('id, link_id, participant_id, schedule_from, submission_timestamp, session_dates')
        .eq('link_id', linkId)
        .maybeSingle();

    if (error) throw new Error('Could not verify participant information.');
    if (!data) throw new Error('This participation link is not valid.');
    if (data.session_dates) throw new Error('You have already submitted your schedule.');

    return { id: data.id, link_id: data.link_id, participant_id: data.participant_id, schedule_from: data.schedule_from };
}

async function fetchAndUpdateAvailability() {
    const { data, error } = await supabaseClient.from('schedules').select('session_dates, backup_dates, instruction_timeslot');
    if (error) throw new Error('Could not fetch schedule data.');

    const bookedDates = new Set();
    const dateCountMap = new Map();
    const takenTimeslots = new Set();
    const takenDateTimeSlots = new Set(); // Track date-time combinations

    data?.forEach(schedule => {
        // Collect taken instruction timeslots with their dates
        if (schedule.instruction_timeslot && schedule.session_dates && Array.isArray(schedule.session_dates) && schedule.session_dates.length > 0) {
            // The instruction timeslot is always on the first session date
            const firstSessionDate = DateManager.normalize(schedule.session_dates[0]);
            
            // Normalize time format: remove seconds if present (13:00:00 -> 13:00)
            const normalizedTime = schedule.instruction_timeslot.substring(0, 5);
            const dateTimeKey = `${firstSessionDate}_${normalizedTime}`;
            takenDateTimeSlots.add(dateTimeKey);
            
            // Also keep the old logic for backward compatibility
            takenTimeslots.add(schedule.instruction_timeslot);
        }
        
        [schedule.session_dates, schedule.backup_dates].forEach(dates => {
            if (dates && Array.isArray(dates)) {
                dates.forEach(d => {
                    const normalizedDate = DateManager.normalize(d);
                    const currentCount = dateCountMap.get(normalizedDate) || 0;
                    dateCountMap.set(normalizedDate, currentCount + 1);
                    
                    if (currentCount + 1 >= SCHEDULER_CONFIG.MAX_CONCURRENT_SESSIONS) {
                        bookedDates.add(normalizedDate);
                    }
                });
            }
        });
    });

    sessionManager.updateAvailability(bookedDates, dateCountMap, takenTimeslots, takenDateTimeSlots);
}

// --- Calendar Population ---
function populateSession1Calendar() {
    elements.session1Calendar.innerHTML = '';
    
    let startDate;
    if (participantInfo.schedule_from) {
        // Parse date string directly to avoid timezone issues
        const [year, month, day] = participantInfo.schedule_from.split('-').map(Number);
        startDate = new Date(year, month - 1, day);
    } else {
        startDate = DateManager.getNextWorkDay(new Date());
    }
    startDate.setHours(0, 0, 0, 0);

    console.log('=== FIRST SESSION CALENDAR DEBUG ==='); // DEBUG_REMOVE
    console.log('Start date for first session search:', DateManager.normalize(startDate)); // DEBUG_REMOVE
    
    // Find the first date where we can schedule 28 consecutive sessions
    const isAvailableForExperiment = (dateString) => {
        // For consecutive period check, we only care about general availability (not blocked dates)
        // because follow-up sessions can be scheduled on blocked dates
        const available = sessionManager.isDateAvailable(dateString);
        console.log(`Consecutive period check ${dateString}: available=${available}`); // DEBUG_REMOVE
        return available;
    };

    const consecutiveStartDate = DateManager.findFirstConsecutiveAvailableDays(
        startDate,
        SCHEDULER_CONFIG.MIN_AVAILABLE_DAYS,
        isAvailableForExperiment
    );

    console.log('Consecutive start date for first session:', consecutiveStartDate ? DateManager.normalize(consecutiveStartDate) : 'null'); // DEBUG_REMOVE

    if (consecutiveStartDate) {
        // Generate 7 dates starting from the consecutive start date
        const availableDates = [];
        let currentDate = new Date(consecutiveStartDate);
        let datesAdded = 0;
        let daysChecked = 0;
        
        while (datesAdded < 7 && daysChecked < 14) {
            const dateStr = DateManager.normalize(currentDate);
            const dayOfWeek = currentDate.getDay();
            
            // Only offer weekdays
            if (dayOfWeek !== 0 && dayOfWeek !== 6) {
                if (sessionManager.isDateAvailableForInstruction(dateStr)) {
                    availableDates.push(new Date(currentDate));
                    datesAdded++;
                    console.log(`Adding first session date: ${dateStr}`); // DEBUG_REMOVE
                }
            }
            
            currentDate.setDate(currentDate.getDate() + 1);
            daysChecked++;
        }
        
        // Create buttons only for available dates
        availableDates.forEach(date => createDateButton(date, elements.session1Calendar, 'session1'));
    } else {
        console.error('No consecutive period found for first session! Using fallback logic.'); // DEBUG_REMOVE
        // Fallback to original logic
        const availableDates = [];
        let currentDate = new Date(startDate);
        let daysChecked = 0;
        const maxDaysToCheck = 365;
        
        while (availableDates.length < 7 && daysChecked < maxDaysToCheck) {
            const dateString = DateManager.normalize(currentDate);
            
            const dayOfWeek = currentDate.getDay();
            if (dayOfWeek !== 0 && dayOfWeek !== 6) {
                if (sessionManager.isDateAvailableForInstruction(dateString)) {
                    availableDates.push(new Date(currentDate));
                }
            }
            
            currentDate.setDate(currentDate.getDate() + 1);
            daysChecked++;
        }
        
        if (availableDates.length < 7) {
            console.warn(`Warning: Only found ${availableDates.length} available instruction dates out of 7 required after checking ${daysChecked} days`);
        }
        
        availableDates.forEach(date => createDateButton(date, elements.session1Calendar, 'session1'));
    }
}

function populateTimeslotButtons() {
    elements.timeslotButtons.innerHTML = '';
    
    // Get the selected date for the first session
    const selectedDate = sessionManager.selectedSessions.length > 0 ? sessionManager.selectedSessions[0] : null;
    
    SCHEDULER_CONFIG.TIME_SLOTS.forEach(timeSlot => {
        // Only show timeslots that are available for the selected date
        if (sessionManager.isTimeslotAvailable(timeSlot, selectedDate)) {
            const button = document.createElement('button');
            button.classList.add('timeslot-button');
            button.textContent = timeSlot;
            button.onclick = () => handleTimeslotSelection(timeSlot, button);
            elements.timeslotButtons.appendChild(button);
        }
    });
    
    if (sessionManager.selectedSessions.length > 0) {
        elements.selectedDateDisplay.textContent = DateManager.formatForDisplay(sessionManager.selectedSessions[0]);
    }
    
    elements.timeslotSection.classList.remove('hidden');
}

function populateFollowUpCalendar() {
    elements.followUpCalendar.innerHTML = '';
    updateFollowUpCount();

    if (sessionManager.selectedSessions.length === 0) return;

    console.log('=== FOLLOW-UP CALENDAR DEBUG ==='); // DEBUG_REMOVE
    console.log('Selected first session:', sessionManager.selectedSessions[0]); // DEBUG_REMOVE

    // Simply generate dates starting from the day after the first session
    // Since the first session was chosen from a consecutive period, the follow-up dates should be consecutive too
    const dates = DateManager.generateFollowUpDates(
        sessionManager.selectedSessions[0],
        SCHEDULER_CONFIG.FOLLOW_UP_WINDOW_DAYS
    );
    
    console.log('Generated follow-up dates:'); // DEBUG_REMOVE
    dates.forEach((date, index) => { // DEBUG_REMOVE
        console.log(`  ${index + 1}: ${DateManager.normalize(date)}`); // DEBUG_REMOVE
    }); // DEBUG_REMOVE
    
    dates.forEach(date => {
        const dateStr = DateManager.normalize(date);
        if (!sessionManager.isDateSelectedInSessions(dateStr)) {
            console.log(`Creating button for follow-up date: ${dateStr}`); // DEBUG_REMOVE
            createDateButton(date, elements.followUpCalendar, 'followUp');
        } else {
            console.log(`Skipping already selected date: ${dateStr}`); // DEBUG_REMOVE
        }
    });
    
    elements.followUpSection.classList.remove('hidden');
    updateFollowUpSectionTitle();
}

function populateBackupCalendar() {
    elements.backupCalendar.innerHTML = '';
    sessionManager.selectedBackups = [];
    updateBackupCount();

    if (sessionManager.selectedSessions.length < SCHEDULER_CONFIG.TOTAL_SESSIONS) return;

    const dates = DateManager.generateBackupDates(sessionManager.selectedSessions, SCHEDULER_CONFIG.BACKUP_WINDOW_DAYS);
    dates.forEach(date => {
        const dateStr = DateManager.normalize(date);
        if (!sessionManager.isDateSelectedInSessions(dateStr)) {
            createDateButton(date, elements.backupCalendar, 'backup');
        }
    });
    
    elements.backupSection.classList.remove('hidden');
}

// --- Date Button Creation and Handling ---
function createDateButton(dateObj, container, type) {
    const dateString = DateManager.normalize(dateObj);
    const button = document.createElement('button');
    button.classList.add('date-button');
    button.dataset.date = dateString;

    const weekday = dateObj.toLocaleDateString(undefined, { weekday: 'short' });
    const dayMonth = dateObj.toLocaleDateString(undefined, { day: 'numeric', month: 'short' });
    button.innerHTML = `${dayMonth}<span class="weekday">${weekday}</span>`;

    const isAvailable = sessionManager.isDateAvailable(dateString);
    const isSelectedInOtherCategory = (type === 'followUp' || type === 'backup') && sessionManager.isDateSelectedInSessions(dateString);

    if (!isAvailable || isSelectedInOtherCategory) {
        button.disabled = true;
        button.title = !isAvailable ? "Date unavailable (maximum concurrent sessions reached)" : "Already selected for another session type";
    } else {
        button.onclick = () => handleDateSelection(dateString, type, button);
    }

    // Mark as selected if appropriate
    const isSelected = (type === 'session1' && sessionManager.selectedSessions[0] === dateString) ||
                      (type === 'followUp' && sessionManager.isDateSelectedInSessions(dateString)) ||
                      (type === 'backup' && sessionManager.isDateSelectedInBackups(dateString));
    
    if (isSelected) button.classList.add('selected');
    container.appendChild(button);
}

function handleDateSelection(dateString, type, button) {
    clearError();
    let result;

    switch (type) {
        case 'session1':
            result = sessionManager.selectFirstSession(dateString);
            
            // Clear all session1 buttons first, then set the selected one
            elements.session1Calendar.querySelectorAll('.date-button').forEach(btn => btn.classList.remove('selected'));
            if (!result.deselected) {
                button.classList.add('selected');
            }
            
            if (result.reset) {
                resetSubsequentSteps();
                if (!result.deselected) populateTimeslotButtons();
            }
            break;

        case 'followUp':
            result = sessionManager.selectFollowUpSession(dateString);
            if (result.success) {
                button.classList.toggle('selected', !result.deselected);
                updateFollowUpCount();
                updateFollowUpSectionTitle();
                
                if (sessionManager.selectedSessions.length === SCHEDULER_CONFIG.TOTAL_SESSIONS) {
                    populateBackupCalendar();
                } else {
                    elements.backupSection.classList.add('hidden');
                }
            } else {
                showError(result.error);
            }
            break;

        case 'backup':
            result = sessionManager.selectBackupSession(dateString);
            if (result.success) {
                button.classList.toggle('selected', !result.deselected);
                updateBackupCount();
            } else {
                showError(result.error);
            }
            break;
    }
    
    checkReviewButtonState();
}

function handleTimeslotSelection(timeSlot, button) {
    clearError();
    elements.timeslotButtons.querySelectorAll('.timeslot-button').forEach(btn => btn.classList.remove('selected'));
    button.classList.add('selected');
    sessionManager.setTimeslot(timeSlot);
    populateFollowUpCalendar();
}

// --- UI Updates ---
function updateFollowUpCount() {
    elements.followUpCount.textContent = sessionManager.getFollowUpCount();
}

function updateBackupCount() {
    elements.backupCount.textContent = sessionManager.selectedBackups.length;
}

function updateFollowUpSectionTitle() {
    // This function can be simplified since we now use updateFollowUpCount() for the counter
    // The title stays static and the count is updated via the span element
}

function checkReviewButtonState() {
    elements.reviewButton.disabled = !sessionManager.isReadyForReview();
    if (elements.reviewButton.disabled) {
        elements.summarySection.classList.add('hidden');
    }
}

function resetSubsequentSteps() {
    elements.timeslotSection.classList.add('hidden');
    elements.followUpSection.classList.add('hidden');
    elements.backupSection.classList.add('hidden');
    updateFollowUpCount();
    updateBackupCount();
}

// --- Review and Submission ---
elements.reviewButton.addEventListener('click', () => {
    const data = sessionManager.getSubmissionData();
    
    elements.logOutput.textContent = `Participant ID: ${participantInfo.participant_id}\n\n` +
        `Instruction Session Time Slot: ${data.instruction_timeslot}\n\n` +
        `Experiment Sessions (${data.session_dates.length}):\n` +
        data.session_dates.map((d, index) => {
            const prefix = index === 0 ? `First (Instruction at ${data.instruction_timeslot})` : `Session ${index + 1}`;
            return `  - ${prefix}: ${DateManager.formatForDisplay(d)}`;
        }).join('\n') + `\n\n` +
        `Backup Sessions (${data.backup_dates.length}):\n` +
        data.backup_dates.map(d => `  - ${DateManager.formatForDisplay(d)}`).join('\n');
    
    elements.summarySection.classList.remove('hidden');
    elements.submitButton.disabled = false;
    elements.submissionStatus.classList.add('hidden');
    elements.pdfStatus.classList.add('hidden');
});

elements.submitButton.addEventListener('click', async () => {
    setSubmissionStatus('Submitting...', 'pending');
    elements.submitButton.disabled = true;
    elements.reviewButton.disabled = true;

    const submissionData = {
        ...sessionManager.getSubmissionData(),
        submission_timestamp: new Date().toISOString()
    };

    try {
        const { error } = await supabaseClient
            .from('schedules')
            .update(submissionData)
            .eq('link_id', participantInfo.link_id);

        if (error) throw error;

        setSubmissionStatus('Schedule submitted successfully!', 'success');
        disableAllDateButtons();
        generateAndDownloadPDF({
            ...submissionData,
            participant_id: participantInfo.link_id
        }, participantInfo.participant_id);
    } catch (err) {
        console.error('Submission error:', err);
        setSubmissionStatus('Submission failed. Please try again.', 'error');
        elements.submitButton.disabled = false;
        elements.reviewButton.disabled = false;
    }
});

// --- Utility Functions ---
function showLoading(message) {
    elements.loadingStatus.textContent = message;
    elements.loadingStatus.classList.remove('hidden');
    elements.schedulerContent.classList.add('hidden');
}

function hideLoading() {
    elements.loadingStatus.classList.add('hidden');
}

function showError(message, element = elements.errorMessages) {
    element.textContent = message;
    element.classList.remove('hidden');
    element.className = element === elements.errorMessages ? 'error-box' : 'status-box error';
}

function clearError(element = elements.errorMessages) {
    element.classList.add('hidden');
    element.textContent = '';
}

function setSubmissionStatus(message, type) {
    elements.submissionStatus.textContent = message;
    elements.submissionStatus.className = `status-box ${type}`;
    elements.submissionStatus.classList.remove('hidden');
}

function disableAllDateButtons() {
    document.querySelectorAll('.date-button').forEach(button => button.disabled = true);
}
