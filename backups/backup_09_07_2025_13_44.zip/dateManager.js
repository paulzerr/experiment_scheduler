// dateManager.js - Centralized date management utilities

class DateManager {
    /**
     * Normalizes any date input to YYYY-MM-DD format
     * @param {Date|string} dateInput - Date object or string
     * @returns {string} Date in YYYY-MM-DD format
     */
    static normalize(dateInput) {
        if (!dateInput) return null;
        
        if (typeof dateInput === 'string') {
            // If it's already in YYYY-MM-DD format, return as-is
            if (/^\d{4}-\d{2}-\d{2}$/.test(dateInput)) {
                return dateInput;
            }
            // Extract date parts directly from string to avoid timezone issues
            const datePart = dateInput.split('T')[0];
            if (/^\d{4}-\d{2}-\d{2}$/.test(datePart)) {
                return datePart;
            }
        }
        
        // For Date objects, extract components directly
        const d = new Date(dateInput);
        const year = d.getFullYear();
        const month = (d.getMonth() + 1).toString().padStart(2, '0');
        const day = d.getDate().toString().padStart(2, '0');
        return `${year}-${month}-${day}`;
    }

    /**
     * Formats a YYYY-MM-DD date string for display
     * @param {string} dateString - Date string in YYYY-MM-DD format
     * @returns {string} Formatted date string
     */
    static formatForDisplay(dateString) {
        if (!dateString) return 'N/A';
        // Parse date string directly to avoid timezone issues
        const [year, month, day] = dateString.split('-').map(Number);
        const date = new Date(year, month - 1, day);
        return date.toLocaleDateString(undefined, {
            weekday: 'long', year: 'numeric', month: 'long', day: 'numeric'
        });
    }

    /**
     * Gets the next work day (Monday-Friday)
     * @param {Date} date - Starting date
     * @returns {Date} Next work day
     */
    static getNextWorkDay(date) {
        const nextDay = new Date(date);
        nextDay.setDate(date.getDate() + 1);
        
        const dayOfWeek = nextDay.getDay();
        if (dayOfWeek === 0) { // Sunday
            nextDay.setDate(nextDay.getDate() + 1);
        } else if (dayOfWeek === 6) { // Saturday
            nextDay.setDate(nextDay.getDate() + 2);
        }
        
        return nextDay;
    }

    /**
     * Generates a range of dates starting from a base date
     * @param {Date} startDate - Starting date
     * @param {number} days - Number of days to generate
     * @returns {Date[]} Array of Date objects
     */
    static generateDateRange(startDate, days) {
        const dates = [];
        for (let i = 0; i < days; i++) {
            const date = new Date(startDate);
            date.setDate(startDate.getDate() + i);
            dates.push(date);
        }
        return dates;
    }

    /**
     * Generates follow-up dates starting from a base date
     * @param {string} baseDateString - Base date in YYYY-MM-DD format
     * @param {number} days - Number of days to generate
     * @returns {Date[]} Array of Date objects
     */
    static generateFollowUpDates(baseDateString, days) {
        // Parse date string directly to avoid timezone issues
        const [year, month, day] = baseDateString.split('-').map(Number);
        const dates = [];
        
        for (let i = 1; i <= days; i++) {
            const newDate = new Date(year, month - 1, day + i);
            dates.push(newDate);
        }
        return dates;
    }

    /**
     * Generates backup dates starting from the day after the last session
     * @param {string[]} sessionDates - Array of session dates in YYYY-MM-DD format
     * @param {number} days - Number of backup days to generate
     * @returns {Date[]} Array of Date objects
     */
    static generateBackupDates(sessionDates, days) {
        const sortedSessions = [...sessionDates].sort();
        const lastSessionDateString = sortedSessions[sortedSessions.length - 1];
        
        // Parse date string directly to avoid timezone issues
        const [year, month, day] = lastSessionDateString.split('-').map(Number);
        const dates = [];
        
        for (let i = 1; i <= days; i++) {
            const newDate = new Date(year, month - 1, day + i);
            dates.push(newDate);
        }
        return dates;
    }

    /**
     * Checks if a date is blocked (no sessions allowed)
     * @param {string} dateString - Date in YYYY-MM-DD format
     * @returns {boolean} True if date is blocked
     */
    static isDateBlocked(dateString) {
        // Get blocked dates from config
        const blockedDates = SCHEDULER_CONFIG.BLOCKED_DATES || [];
        return blockedDates.includes(dateString);
    }

    /**
     * Filters out blocked dates from an array of dates
     * @param {Date[]} dates - Array of Date objects
     * @returns {Date[]} Array of Date objects excluding blocked dates
     */
    static filterBlockedDates(dates) {
        return dates.filter(date => {
            const dateString = this.normalize(date);
            return !this.isDateBlocked(dateString);
        });
    }

    /**
     * Finds the first date from which the specified number of available weekdays can be found
     * within a reasonable timeframe (allowing for weekends and some blocked days)
     * @param {Date} startDate - Starting date to search from
     * @param {number} requiredDays - Number of available weekdays required
     * @param {function} isAvailableCallback - Function to check if a date is available
     * @param {number} maxSearchDays - Maximum days to search (default: 365)
     * @returns {Date|null} First date from which enough days are available, or null if not found
     */
    static findFirstConsecutiveAvailableDays(startDate, requiredDays, isAvailableCallback, maxSearchDays = 365) {
        console.log('=== CONSECUTIVE SEARCH ALGORITHM DEBUG ==='); // DEBUG_REMOVE
        console.log('Start date:', this.normalize(startDate)); // DEBUG_REMOVE
        console.log('Required days:', requiredDays); // DEBUG_REMOVE
        console.log('Max search days:', maxSearchDays); // DEBUG_REMOVE
        
        let searchDate = new Date(startDate);
        let daysSearched = 0;
        
        while (daysSearched < maxSearchDays) {
            console.log(`\n--- Checking for consecutive days starting from: ${this.normalize(searchDate)} (day ${daysSearched + 1}) ---`); // DEBUG_REMOVE
            
            // Look for actual consecutive available weekdays
            let consecutiveCount = 0;
            let checkDate = new Date(searchDate);
            let firstAvailableDate = null;
            let daysChecked = 0;
            const maxDaysToCheck = requiredDays * 3; // Allow some buffer for weekends and unavailable days
            
            while (daysChecked < maxDaysToCheck && consecutiveCount < requiredDays) {
                const dateString = this.normalize(checkDate);
                const dayOfWeek = checkDate.getDay();
                const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']; // DEBUG_REMOVE
                
                // Only count weekdays
                if (dayOfWeek !== 0 && dayOfWeek !== 6) {
                    const isAvailable = isAvailableCallback(dateString);
                    if (isAvailable) {
                        if (consecutiveCount === 0) {
                            firstAvailableDate = new Date(checkDate);
                            console.log(`  🎯 First available date found: ${dateString} (${dayNames[dayOfWeek]})`); // DEBUG_REMOVE
                        }
                        consecutiveCount++;
                        console.log(`  ✓ ${dateString} (${dayNames[dayOfWeek]}) - Available (consecutive: ${consecutiveCount}/${requiredDays})`); // DEBUG_REMOVE
                    } else {
                        if (consecutiveCount > 0) {
                            console.log(`  ✗ ${dateString} (${dayNames[dayOfWeek]}) - Not available (breaking consecutive chain at ${consecutiveCount})`); // DEBUG_REMOVE
                            consecutiveCount = 0; // Reset consecutive count
                            firstAvailableDate = null;
                        } else {
                            console.log(`  ✗ ${dateString} (${dayNames[dayOfWeek]}) - Not available`); // DEBUG_REMOVE
                        }
                    }
                } else {
                    console.log(`  - ${dateString} (${dayNames[dayOfWeek]}) - Weekend (skipped)`); // DEBUG_REMOVE
                }
                
                checkDate.setDate(checkDate.getDate() + 1);
                daysChecked++;
            }
            
            console.log(`Consecutive search result: Found ${consecutiveCount}/${requiredDays} consecutive available days`); // DEBUG_REMOVE
            
            // If we found enough consecutive available days, return the first available date
            if (consecutiveCount >= requiredDays && firstAvailableDate) {
                console.log(`SUCCESS: Found ${consecutiveCount} consecutive available days starting from ${this.normalize(firstAvailableDate)}`); // DEBUG_REMOVE
                return firstAvailableDate;
            }
            
            // Move to next day and continue searching
            searchDate.setDate(searchDate.getDate() + 1);
            daysSearched++;
        }
        
        console.log('FAILURE: No suitable consecutive period found within search limit'); // DEBUG_REMOVE
        return null; // No suitable period found
    }
}